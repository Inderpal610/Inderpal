/*
 * @author Raquel Díaz González
 */

kurento_room.factory('ServiceParticipant', function () {

    return new Participants();

});